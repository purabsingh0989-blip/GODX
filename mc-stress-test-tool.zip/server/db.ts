import { eq, desc, and } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, serverConfigs, proxyIps, botSettings, testSessions, bots, performanceMetrics, botActivityLogs } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Server Config queries
export async function getServerConfig(configId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(serverConfigs).where(eq(serverConfigs.id, configId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserServerConfigs(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(serverConfigs).where(eq(serverConfigs.userId, userId));
}

// Proxy IP queries
export async function getActiveProxyIps(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(proxyIps).where(and(eq(proxyIps.userId, userId), eq(proxyIps.isActive, true)));
}

export async function getUserProxyIps(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(proxyIps).where(eq(proxyIps.userId, userId));
}

// Bot Settings queries
export async function getBotSettings(settingsId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(botSettings).where(eq(botSettings.id, settingsId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserBotSettings(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(botSettings).where(eq(botSettings.userId, userId));
}

// Test Session queries
export async function getTestSession(sessionId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(testSessions).where(eq(testSessions.id, sessionId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserTestSessions(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(testSessions).where(eq(testSessions.userId, userId)).orderBy(desc(testSessions.createdAt));
}

// Bot queries
export async function getSessionBots(sessionId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(bots).where(eq(bots.sessionId, sessionId));
}

export async function getSessionBotStats(sessionId: number) {
  const db = await getDb();
  if (!db) return { connected: 0, disconnected: 0, error: 0, kicked: 0, total: 0 };
  const botList = await db.select().from(bots).where(eq(bots.sessionId, sessionId));
  return {
    connected: botList.filter(b => b.status === 'connected').length,
    disconnected: botList.filter(b => b.status === 'disconnected').length,
    error: botList.filter(b => b.status === 'error').length,
    kicked: botList.filter(b => b.status === 'kicked').length,
    total: botList.length,
  };
}

// Performance Metrics queries
export async function getLatestMetrics(sessionId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(performanceMetrics).where(eq(performanceMetrics.sessionId, sessionId)).orderBy(desc(performanceMetrics.timestamp)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getSessionMetrics(sessionId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(performanceMetrics).where(eq(performanceMetrics.sessionId, sessionId)).orderBy(desc(performanceMetrics.timestamp)).limit(limit);
}

// Bot Activity Logs queries
export async function getSessionLogs(sessionId: number, limit: number = 100) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(botActivityLogs).where(eq(botActivityLogs.sessionId, sessionId)).orderBy(desc(botActivityLogs.createdAt)).limit(limit);
}

export async function getBotLogs(botId: number, limit: number = 50) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(botActivityLogs).where(eq(botActivityLogs.botId, botId)).orderBy(desc(botActivityLogs.createdAt)).limit(limit);
}


