import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { testSessions, bots, botActivityLogs } from "../../drizzle/schema";

const testPresets = {
  light: { bots: 10, joinDelay: 2000 },
  medium: { bots: 50, joinDelay: 1000 },
  heavy: { bots: 100, joinDelay: 500 },
  extreme: { bots: 250, joinDelay: 200 },
};

export const botManagementRouter = router({
  // Create a new test session
  createSession: protectedProcedure
    .input(
      z.object({
        sessionName: z.string().min(1),
        serverConfigId: z.number(),
        botSettingsId: z.number(),
        testPreset: z.enum(["light", "medium", "heavy", "extreme", "custom"]),
        totalBots: z.number().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(testSessions).values({
        userId: ctx.user.id,
        sessionName: input.sessionName,
        serverConfigId: input.serverConfigId,
        botSettingsId: input.botSettingsId,
        testPreset: input.testPreset,
        totalBots: input.totalBots,
        status: "idle",
      });

      const sessions = await db.select().from(testSessions).orderBy(desc(testSessions.createdAt)).limit(1);
      return { id: sessions[0]?.id || 0 };
    }),

  // Start a test session
  startSession: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const session = await db.select().from(testSessions).where(eq(testSessions.id, input.sessionId)).limit(1);
      if (!session.length || session[0].userId !== ctx.user.id) {
        throw new Error("Session not found or unauthorized");
      }

      await db.update(testSessions).set({
        status: "running",
        startTime: new Date(),
      }).where(eq(testSessions.id, input.sessionId));

      return { success: true };
    }),

  // Pause a test session
  pauseSession: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.update(testSessions).set({
        status: "paused",
      }).where(eq(testSessions.id, input.sessionId));

      return { success: true };
    }),

  // Stop a test session
  stopSession: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.update(testSessions).set({
        status: "completed",
        endTime: new Date(),
      }).where(eq(testSessions.id, input.sessionId));

      return { success: true };
    }),

  // Get user's test sessions
  getSessions: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];

    return await db
      .select()
      .from(testSessions)
      .where(eq(testSessions.userId, ctx.user.id))
      .orderBy(desc(testSessions.createdAt));
  }),

  // Get session details
  getSession: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      const result = await db
        .select()
        .from(testSessions)
        .where(eq(testSessions.id, input.sessionId))
        .limit(1);

      if (!result.length || result[0]!.userId !== ctx.user.id) {
        return null;
      }

      return result[0];
    }),

  // Get session bots
  getSessionBots: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      return await db.select().from(bots).where(eq(bots.sessionId, input.sessionId));
    }),

  // Add activity log
  addActivityLog: protectedProcedure
    .input(
      z.object({
        botId: z.number(),
        sessionId: z.number(),
        eventType: z.enum(["connected", "disconnected", "error", "kicked", "chat", "movement", "respawn"]),
        message: z.string().optional(),
        details: z.any().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(botActivityLogs).values({
        botId: input.botId,
        sessionId: input.sessionId,
        eventType: input.eventType,
        message: input.message,
        details: input.details,
      });

      return { success: true };
    }),

  // Get activity logs for session
  getActivityLogs: protectedProcedure
    .input(z.object({ sessionId: z.number(), limit: z.number().default(100) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      return await db
        .select()
        .from(botActivityLogs)
        .where(eq(botActivityLogs.sessionId, input.sessionId))
        .orderBy(desc(botActivityLogs.createdAt))
        .limit(input.limit);
    }),
});
