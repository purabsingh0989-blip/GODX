import { z } from "zod";
import { eq } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { botSettings } from "../../drizzle/schema";

export const botSettingsRouter = router({
  // Create new bot settings
  createSettings: protectedProcedure
    .input(
      z.object({
        settingsName: z.string().min(1),
        usernamePattern: z.string().default("Bot_{number}"),
        joinDelay: z.number().int().default(1000),
        enableMovement: z.boolean().default(true),
        enableChat: z.boolean().default(false),
        chatMessages: z.array(z.string()).optional(),
        chatInterval: z.number().int().default(30000),
        autoRespawn: z.boolean().default(true),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(botSettings).values({
        userId: ctx.user.id,
        settingsName: input.settingsName,
        usernamePattern: input.usernamePattern,
        joinDelay: input.joinDelay,
        enableMovement: input.enableMovement,
        enableChat: input.enableChat,
        chatMessages: input.chatMessages,
        chatInterval: input.chatInterval,
        autoRespawn: input.autoRespawn,
      });

      return { success: true };
    }),

  // Get user's bot settings
  getSettings: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];

    return await db
      .select()
      .from(botSettings)
      .where(eq(botSettings.userId, ctx.user.id));
  }),

  // Get specific bot settings
  getSetting: protectedProcedure
    .input(z.object({ settingId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      const result = await db
        .select()
        .from(botSettings)
        .where(eq(botSettings.id, input.settingId))
        .limit(1);

      if (!result.length || result[0]!.userId !== ctx.user.id) {
        return null;
      }

      return result[0];
    }),

  // Update bot settings
  updateSettings: protectedProcedure
    .input(
      z.object({
        settingId: z.number(),
        settingsName: z.string().optional(),
        usernamePattern: z.string().optional(),
        joinDelay: z.number().int().optional(),
        enableMovement: z.boolean().optional(),
        enableChat: z.boolean().optional(),
        chatMessages: z.array(z.string()).optional(),
        chatInterval: z.number().int().optional(),
        autoRespawn: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const setting = await db
        .select()
        .from(botSettings)
        .where(eq(botSettings.id, input.settingId))
        .limit(1);

      if (!setting.length || setting[0]!.userId !== ctx.user.id) {
        throw new Error("Settings not found or unauthorized");
      }

      const updateData: Record<string, any> = {};
      if (input.settingsName) updateData.settingsName = input.settingsName;
      if (input.usernamePattern) updateData.usernamePattern = input.usernamePattern;
      if (input.joinDelay !== undefined) updateData.joinDelay = input.joinDelay;
      if (input.enableMovement !== undefined) updateData.enableMovement = input.enableMovement;
      if (input.enableChat !== undefined) updateData.enableChat = input.enableChat;
      if (input.chatMessages) updateData.chatMessages = input.chatMessages;
      if (input.chatInterval !== undefined) updateData.chatInterval = input.chatInterval;
      if (input.autoRespawn !== undefined) updateData.autoRespawn = input.autoRespawn;

      await db.update(botSettings).set(updateData).where(eq(botSettings.id, input.settingId));

      return { success: true };
    }),

  // Delete bot settings
  deleteSettings: protectedProcedure
    .input(z.object({ settingId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const setting = await db
        .select()
        .from(botSettings)
        .where(eq(botSettings.id, input.settingId))
        .limit(1);

      if (!setting.length || setting[0]!.userId !== ctx.user.id) {
        throw new Error("Settings not found or unauthorized");
      }

      await db.delete(botSettings).where(eq(botSettings.id, input.settingId));

      return { success: true };
    }),
});
