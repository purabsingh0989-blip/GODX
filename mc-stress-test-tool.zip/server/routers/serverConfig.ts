import { z } from "zod";
import { eq } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { serverConfigs } from "../../drizzle/schema";

export const serverConfigRouter = router({
  // Create a new server configuration
  createConfig: protectedProcedure
    .input(
      z.object({
        serverIp: z.string().min(1),
        serverPort: z.number().int().min(1).max(65535),
        minecraftVersion: z.string().default("1.20.1"),
        serverName: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(serverConfigs).values({
        userId: ctx.user.id,
        serverIp: input.serverIp,
        serverPort: input.serverPort,
        minecraftVersion: input.minecraftVersion,
        serverName: input.serverName,
        isActive: true,
      });

      return { success: true };
    }),

  // Get user's server configurations
  getConfigs: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];

    return await db
      .select()
      .from(serverConfigs)
      .where(eq(serverConfigs.userId, ctx.user.id));
  }),

  // Get specific server configuration
  getConfig: protectedProcedure
    .input(z.object({ configId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      const result = await db
        .select()
        .from(serverConfigs)
        .where(eq(serverConfigs.id, input.configId))
        .limit(1);

      if (!result.length || result[0]!.userId !== ctx.user.id) {
        return null;
      }

      return result[0];
    }),

  // Update server configuration
  updateConfig: protectedProcedure
    .input(
      z.object({
        configId: z.number(),
        serverIp: z.string().optional(),
        serverPort: z.number().int().optional(),
        minecraftVersion: z.string().optional(),
        serverName: z.string().optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const config = await db
        .select()
        .from(serverConfigs)
        .where(eq(serverConfigs.id, input.configId))
        .limit(1);

      if (!config.length || config[0]!.userId !== ctx.user.id) {
        throw new Error("Configuration not found or unauthorized");
      }

      const updateData: Record<string, any> = {};
      if (input.serverIp) updateData.serverIp = input.serverIp;
      if (input.serverPort) updateData.serverPort = input.serverPort;
      if (input.minecraftVersion) updateData.minecraftVersion = input.minecraftVersion;
      if (input.serverName !== undefined) updateData.serverName = input.serverName;
      if (input.isActive !== undefined) updateData.isActive = input.isActive;

      await db.update(serverConfigs).set(updateData).where(eq(serverConfigs.id, input.configId));

      return { success: true };
    }),

  // Delete server configuration
  deleteConfig: protectedProcedure
    .input(z.object({ configId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const config = await db
        .select()
        .from(serverConfigs)
        .where(eq(serverConfigs.id, input.configId))
        .limit(1);

      if (!config.length || config[0]!.userId !== ctx.user.id) {
        throw new Error("Configuration not found or unauthorized");
      }

      await db.delete(serverConfigs).where(eq(serverConfigs.id, input.configId));

      return { success: true };
    }),
});
