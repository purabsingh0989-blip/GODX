import { describe, it, expect, beforeEach } from "vitest";
import { serverConfigRouter } from "./serverConfig";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("serverConfig router", () => {
  let ctx: TrpcContext;

  beforeEach(() => {
    ctx = createTestContext();
  });

  describe("createConfig", () => {
    it("should create a server configuration", async () => {
      const caller = serverConfigRouter.createCaller(ctx);

      const result = await caller.createConfig({
        serverIp: "192.168.1.1",
        serverPort: 25565,
        minecraftVersion: "1.20.1",
        serverName: "Test Server",
      });

      expect(result).toHaveProperty("success");
      expect(result.success).toBe(true);
    });

    it("should require server IP", async () => {
      const caller = serverConfigRouter.createCaller(ctx);

      try {
        await caller.createConfig({
          serverIp: "",
          serverPort: 25565,
          minecraftVersion: "1.20.1",
        });
        expect.fail("Should have thrown an error");
      } catch (error) {
        expect(error).toBeDefined();
      }
    });
  });

  describe("getConfigs", () => {
    it("should retrieve user configurations", async () => {
      const caller = serverConfigRouter.createCaller(ctx);

      const configs = await caller.getConfigs();

      expect(Array.isArray(configs)).toBe(true);
    });
  });

  describe("getConfig", () => {
    it("should retrieve specific configuration", async () => {
      const caller = serverConfigRouter.createCaller(ctx);

      const config = await caller.getConfig({ configId: 1 });

      // Config may be null if it doesn't exist, which is valid
      expect(config === null || typeof config === "object").toBe(true);
    });
  });

  describe("updateConfig", () => {
    it("should update configuration", async () => {
      const caller = serverConfigRouter.createCaller(ctx);

      expect(caller.updateConfig).toBeDefined();
    });
  });

  describe("deleteConfig", () => {
    it("should delete configuration", async () => {
      const caller = serverConfigRouter.createCaller(ctx);

      expect(caller.deleteConfig).toBeDefined();
    });
  });
});
