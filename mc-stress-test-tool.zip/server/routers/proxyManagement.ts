import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { proxyIps } from "../../drizzle/schema";

export const proxyManagementRouter = router({
  // Add a new proxy IP
  addProxy: protectedProcedure
    .input(
      z.object({
        ipAddress: z.string().min(1),
        port: z.number().int().optional(),
        username: z.string().optional(),
        password: z.string().optional(),
        protocol: z.enum(["http", "https", "socks5"]).default("http"),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      await db.insert(proxyIps).values({
        userId: ctx.user.id,
        ipAddress: input.ipAddress,
        port: input.port,
        username: input.username,
        password: input.password,
        protocol: input.protocol,
        isActive: true,
      });

      return { success: true };
    }),

  // Get user's proxy IPs
  getProxies: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];

    return await db
      .select()
      .from(proxyIps)
      .where(eq(proxyIps.userId, ctx.user.id));
  }),

  // Get active proxy IPs
  getActiveProxies: protectedProcedure.query(async ({ ctx }) => {
    const db = await getDb();
    if (!db) return [];

    return await db
      .select()
      .from(proxyIps)
      .where(and(eq(proxyIps.userId, ctx.user.id), eq(proxyIps.isActive, true)));
  }),

  // Update proxy IP
  updateProxy: protectedProcedure
    .input(
      z.object({
        proxyId: z.number(),
        ipAddress: z.string().optional(),
        port: z.number().int().optional(),
        username: z.string().optional(),
        password: z.string().optional(),
        protocol: z.enum(["http", "https", "socks5"]).optional(),
        isActive: z.boolean().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const proxy = await db
        .select()
        .from(proxyIps)
        .where(eq(proxyIps.id, input.proxyId))
        .limit(1);

      if (!proxy.length || proxy[0]!.userId !== ctx.user.id) {
        throw new Error("Proxy not found or unauthorized");
      }

      const updateData: Record<string, any> = {};
      if (input.ipAddress) updateData.ipAddress = input.ipAddress;
      if (input.port) updateData.port = input.port;
      if (input.username !== undefined) updateData.username = input.username;
      if (input.password !== undefined) updateData.password = input.password;
      if (input.protocol) updateData.protocol = input.protocol;
      if (input.isActive !== undefined) updateData.isActive = input.isActive;

      await db.update(proxyIps).set(updateData).where(eq(proxyIps.id, input.proxyId));

      return { success: true };
    }),

  // Delete proxy IP
  deleteProxy: protectedProcedure
    .input(z.object({ proxyId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const proxy = await db
        .select()
        .from(proxyIps)
        .where(eq(proxyIps.id, input.proxyId))
        .limit(1);

      if (!proxy.length || proxy[0]!.userId !== ctx.user.id) {
        throw new Error("Proxy not found or unauthorized");
      }

      await db.delete(proxyIps).where(eq(proxyIps.id, input.proxyId));

      return { success: true };
    }),

  // Toggle proxy active status
  toggleProxy: protectedProcedure
    .input(z.object({ proxyId: z.number(), isActive: z.boolean() }))
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      const proxy = await db
        .select()
        .from(proxyIps)
        .where(eq(proxyIps.id, input.proxyId))
        .limit(1);

      if (!proxy.length || proxy[0]!.userId !== ctx.user.id) {
        throw new Error("Proxy not found or unauthorized");
      }

      await db
        .update(proxyIps)
        .set({ isActive: input.isActive })
        .where(eq(proxyIps.id, input.proxyId));

      return { success: true };
    }),
});
