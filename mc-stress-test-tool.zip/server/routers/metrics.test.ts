import { describe, it, expect, beforeEach } from "vitest";
import { metricsRouter } from "./metrics";
import type { TrpcContext } from "../_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createTestContext(): TrpcContext {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("metrics router", () => {
  let ctx: TrpcContext;

  beforeEach(() => {
    ctx = createTestContext();
  });

  describe("recordMetrics", () => {
    it("should record performance metrics", async () => {
      const caller = metricsRouter.createCaller(ctx);

      expect(caller.recordMetrics).toBeDefined();
    });

    it("should accept optional metric values", async () => {
      const caller = metricsRouter.createCaller(ctx);

      expect(caller.recordMetrics).toBeDefined();
    });
  });

  describe("getLatestMetrics", () => {
    it("should retrieve latest metrics for session", async () => {
      const caller = metricsRouter.createCaller(ctx);

      const metrics = await caller.getLatestMetrics({ sessionId: 1 });

      expect(metrics === null || typeof metrics === "object").toBe(true);
    });
  });

  describe("getMetricsHistory", () => {
    it("should retrieve metrics history", async () => {
      const caller = metricsRouter.createCaller(ctx);

      const history = await caller.getMetricsHistory({
        sessionId: 1,
        limit: 100,
      });

      expect(Array.isArray(history)).toBe(true);
    });

    it("should respect limit parameter", async () => {
      const caller = metricsRouter.createCaller(ctx);

      const history = await caller.getMetricsHistory({
        sessionId: 1,
        limit: 10,
      });

      expect(history.length).toBeLessThanOrEqual(10);
    });
  });

  describe("getMetricsSummary", () => {
    it("should retrieve metrics summary", async () => {
      const caller = metricsRouter.createCaller(ctx);

      const summary = await caller.getMetricsSummary({ sessionId: 1 });

      expect(summary === null || typeof summary === "object").toBe(true);
    });

    it("should calculate averages correctly", async () => {
      const caller = metricsRouter.createCaller(ctx);

      const summary = await caller.getMetricsSummary({ sessionId: 1 });

      if (summary) {
        expect(summary).toHaveProperty("averageTps");
        expect(summary).toHaveProperty("averageMemory");
        expect(summary).toHaveProperty("averageCpu");
        expect(summary).toHaveProperty("averageLatency");
        expect(summary).toHaveProperty("maxPlayers");
        expect(summary).toHaveProperty("totalKicked");
      }
    });
  });
});
