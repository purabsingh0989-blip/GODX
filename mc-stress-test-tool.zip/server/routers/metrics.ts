import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { protectedProcedure, router } from "../_core/trpc";
import { getDb } from "../db";
import { performanceMetrics, testSessions } from "../../drizzle/schema";

export const metricsRouter = router({
  // Record performance metrics
  recordMetrics: protectedProcedure
    .input(
      z.object({
        sessionId: z.number(),
        tps: z.number().optional(),
        playerCount: z.number().optional(),
        memoryUsage: z.number().optional(),
        memoryMax: z.number().optional(),
        cpuUsage: z.number().optional(),
        connectedBots: z.number().optional(),
        disconnectedBots: z.number().optional(),
        kickedBots: z.number().optional(),
        averageLatency: z.number().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) throw new Error("Database not available");

      // Verify user owns this session
      const session = await db
        .select()
        .from(testSessions)
        .where(eq(testSessions.id, input.sessionId))
        .limit(1);

      if (!session.length || session[0]!.userId !== ctx.user.id) {
        throw new Error("Session not found or unauthorized");
      }

      const values: any = {
        sessionId: input.sessionId,
      };
      if (input.tps !== undefined) values.tps = input.tps.toFixed(2);
      if (input.playerCount !== undefined) values.playerCount = input.playerCount;
      if (input.memoryUsage !== undefined) values.memoryUsage = input.memoryUsage.toFixed(2);
      if (input.memoryMax !== undefined) values.memoryMax = input.memoryMax.toFixed(2);
      if (input.cpuUsage !== undefined) values.cpuUsage = input.cpuUsage.toFixed(2);
      if (input.connectedBots !== undefined) values.connectedBots = input.connectedBots;
      if (input.disconnectedBots !== undefined) values.disconnectedBots = input.disconnectedBots;
      if (input.kickedBots !== undefined) values.kickedBots = input.kickedBots;
      if (input.averageLatency !== undefined) values.averageLatency = input.averageLatency.toFixed(2);

      await db.insert(performanceMetrics).values(values);

      return { success: true };
    }),

  // Get latest metrics for a session
  getLatestMetrics: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      // Verify user owns this session
      const session = await db
        .select()
        .from(testSessions)
        .where(eq(testSessions.id, input.sessionId))
        .limit(1);

      if (!session.length || session[0]!.userId !== ctx.user.id) {
        return null;
      }

      const result = await db
        .select()
        .from(performanceMetrics)
        .where(eq(performanceMetrics.sessionId, input.sessionId))
        .orderBy(desc(performanceMetrics.timestamp))
        .limit(1);

      return result.length > 0 ? result[0] : null;
    }),

  // Get metrics history for a session
  getMetricsHistory: protectedProcedure
    .input(z.object({ sessionId: z.number(), limit: z.number().default(100) }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return [];

      // Verify user owns this session
      const session = await db
        .select()
        .from(testSessions)
        .where(eq(testSessions.id, input.sessionId))
        .limit(1);

      if (!session.length || session[0]!.userId !== ctx.user.id) {
        return [];
      }

      return await db
        .select()
        .from(performanceMetrics)
        .where(eq(performanceMetrics.sessionId, input.sessionId))
        .orderBy(desc(performanceMetrics.timestamp))
        .limit(input.limit);
    }),

  // Get metrics summary for a session
  getMetricsSummary: protectedProcedure
    .input(z.object({ sessionId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = await getDb();
      if (!db) return null;

      // Verify user owns this session
      const session = await db
        .select()
        .from(testSessions)
        .where(eq(testSessions.id, input.sessionId))
        .limit(1);

      if (!session.length || session[0]!.userId !== ctx.user.id) {
        return null;
      }

      const metrics = await db
        .select()
        .from(performanceMetrics)
        .where(eq(performanceMetrics.sessionId, input.sessionId));

      if (!metrics.length) {
        return null;
      }

      const avgTps = metrics.reduce((sum, m) => sum + (m.tps ? parseFloat(m.tps.toString()) : 0), 0) / metrics.length;
      const avgMemory = metrics.reduce((sum, m) => sum + (m.memoryUsage ? parseFloat(m.memoryUsage.toString()) : 0), 0) / metrics.length;
      const avgCpu = metrics.reduce((sum, m) => sum + (m.cpuUsage ? parseFloat(m.cpuUsage.toString()) : 0), 0) / metrics.length;
      const avgLatency = metrics.reduce((sum, m) => sum + (m.averageLatency ? parseFloat(m.averageLatency.toString()) : 0), 0) / metrics.length;
      const maxPlayers = Math.max(...metrics.map(m => m.playerCount || 0));
      const totalKicked = metrics.reduce((sum, m) => sum + (m.kickedBots || 0), 0);

      return {
        averageTps: parseFloat(avgTps.toFixed(2)),
        averageMemory: parseFloat(avgMemory.toFixed(2)),
        averageCpu: parseFloat(avgCpu.toFixed(2)),
        averageLatency: parseFloat(avgLatency.toFixed(2)),
        maxPlayers,
        totalKicked,
        metricsCount: metrics.length,
      };
    }),
});
