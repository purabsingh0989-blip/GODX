import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Server Configuration
export const serverConfigs = mysqlTable("serverConfigs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  serverIp: varchar("serverIp", { length: 255 }).notNull(),
  serverPort: int("serverPort").notNull().default(25565),
  minecraftVersion: varchar("minecraftVersion", { length: 32 }).notNull().default("1.20.1"),
  serverName: varchar("serverName", { length: 255 }),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type ServerConfig = typeof serverConfigs.$inferSelect;
export type InsertServerConfig = typeof serverConfigs.$inferInsert;

// Proxy IPs
export const proxyIps = mysqlTable("proxyIps", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  ipAddress: varchar("ipAddress", { length: 255 }).notNull(),
  port: int("port"),
  username: varchar("username", { length: 255 }),
  password: varchar("password", { length: 255 }),
  protocol: mysqlEnum("protocol", ["http", "https", "socks5"]).default("http").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  lastUsed: timestamp("lastUsed"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ProxyIp = typeof proxyIps.$inferSelect;
export type InsertProxyIp = typeof proxyIps.$inferInsert;

// Bot Settings
export const botSettings = mysqlTable("botSettings", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  settingsName: varchar("settingsName", { length: 255 }).notNull(),
  usernamePattern: varchar("usernamePattern", { length: 255 }).notNull().default("Bot_{number}"),
  joinDelay: int("joinDelay").notNull().default(1000),
  enableMovement: boolean("enableMovement").default(true).notNull(),
  enableChat: boolean("enableChat").default(false).notNull(),
  chatMessages: json("chatMessages"),
  chatInterval: int("chatInterval").default(30000),
  autoRespawn: boolean("autoRespawn").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type BotSettings = typeof botSettings.$inferSelect;
export type InsertBotSettings = typeof botSettings.$inferInsert;

// Test Sessions
export const testSessions = mysqlTable("testSessions", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  sessionName: varchar("sessionName", { length: 255 }).notNull(),
  serverConfigId: int("serverConfigId").notNull(),
  botSettingsId: int("botSettingsId").notNull(),
  testPreset: mysqlEnum("testPreset", ["light", "medium", "heavy", "extreme", "custom"]).default("custom").notNull(),
  totalBots: int("totalBots").notNull(),
  status: mysqlEnum("status", ["idle", "running", "paused", "completed", "failed"]).default("idle").notNull(),
  startTime: timestamp("startTime"),
  endTime: timestamp("endTime"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type TestSession = typeof testSessions.$inferSelect;
export type InsertTestSession = typeof testSessions.$inferInsert;

// Bots
export const bots = mysqlTable("bots", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  username: varchar("username", { length: 255 }).notNull(),
  status: mysqlEnum("status", ["idle", "connecting", "connected", "disconnected", "error", "kicked"]).default("idle").notNull(),
  proxyIpId: int("proxyIpId"),
  connectedAt: timestamp("connectedAt"),
  disconnectedAt: timestamp("disconnectedAt"),
  lastError: text("lastError"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Bot = typeof bots.$inferSelect;
export type InsertBot = typeof bots.$inferInsert;

// Performance Metrics
export const performanceMetrics = mysqlTable("performanceMetrics", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("sessionId").notNull(),
  timestamp: timestamp("timestamp").defaultNow().notNull(),
  tps: decimal("tps", { precision: 5, scale: 2 }),
  playerCount: int("playerCount"),
  memoryUsage: decimal("memoryUsage", { precision: 10, scale: 2 }),
  memoryMax: decimal("memoryMax", { precision: 10, scale: 2 }),
  cpuUsage: decimal("cpuUsage", { precision: 5, scale: 2 }),
  connectedBots: int("connectedBots"),
  disconnectedBots: int("disconnectedBots"),
  kickedBots: int("kickedBots"),
  averageLatency: decimal("averageLatency", { precision: 8, scale: 2 }),
});

export type PerformanceMetric = typeof performanceMetrics.$inferSelect;
export type InsertPerformanceMetric = typeof performanceMetrics.$inferInsert;

// Bot Activity Logs
export const botActivityLogs = mysqlTable("botActivityLogs", {
  id: int("id").autoincrement().primaryKey(),
  botId: int("botId").notNull(),
  sessionId: int("sessionId").notNull(),
  eventType: mysqlEnum("eventType", ["connected", "disconnected", "error", "kicked", "chat", "movement", "respawn"]).notNull(),
  message: text("message"),
  details: json("details"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type BotActivityLog = typeof botActivityLogs.$inferSelect;
export type InsertBotActivityLog = typeof botActivityLogs.$inferInsert;