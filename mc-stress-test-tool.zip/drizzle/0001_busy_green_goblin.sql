CREATE TABLE `botActivityLogs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`botId` int NOT NULL,
	`sessionId` int NOT NULL,
	`eventType` enum('connected','disconnected','error','kicked','chat','movement','respawn') NOT NULL,
	`message` text,
	`details` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `botActivityLogs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `botSettings` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`settingsName` varchar(255) NOT NULL,
	`usernamePattern` varchar(255) NOT NULL DEFAULT 'Bot_{number}',
	`joinDelay` int NOT NULL DEFAULT 1000,
	`enableMovement` boolean NOT NULL DEFAULT true,
	`enableChat` boolean NOT NULL DEFAULT false,
	`chatMessages` json,
	`chatInterval` int DEFAULT 30000,
	`autoRespawn` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `botSettings_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `bots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`username` varchar(255) NOT NULL,
	`status` enum('idle','connecting','connected','disconnected','error','kicked') NOT NULL DEFAULT 'idle',
	`proxyIpId` int,
	`connectedAt` timestamp,
	`disconnectedAt` timestamp,
	`lastError` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `bots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `performanceMetrics` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` int NOT NULL,
	`timestamp` timestamp NOT NULL DEFAULT (now()),
	`tps` decimal(5,2),
	`playerCount` int,
	`memoryUsage` decimal(10,2),
	`memoryMax` decimal(10,2),
	`cpuUsage` decimal(5,2),
	`connectedBots` int,
	`disconnectedBots` int,
	`kickedBots` int,
	`averageLatency` decimal(8,2),
	CONSTRAINT `performanceMetrics_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `proxyIps` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`ipAddress` varchar(255) NOT NULL,
	`port` int,
	`username` varchar(255),
	`password` varchar(255),
	`protocol` enum('http','https','socks5') NOT NULL DEFAULT 'http',
	`isActive` boolean NOT NULL DEFAULT true,
	`lastUsed` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `proxyIps_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `serverConfigs` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`serverIp` varchar(255) NOT NULL,
	`serverPort` int NOT NULL DEFAULT 25565,
	`minecraftVersion` varchar(32) NOT NULL DEFAULT '1.20.1',
	`serverName` varchar(255),
	`isActive` boolean NOT NULL DEFAULT true,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `serverConfigs_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `testSessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`userId` int NOT NULL,
	`sessionName` varchar(255) NOT NULL,
	`serverConfigId` int NOT NULL,
	`botSettingsId` int NOT NULL,
	`testPreset` enum('light','medium','heavy','extreme','custom') NOT NULL DEFAULT 'custom',
	`totalBots` int NOT NULL,
	`status` enum('idle','running','paused','completed','failed') NOT NULL DEFAULT 'idle',
	`startTime` timestamp,
	`endTime` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `testSessions_id` PRIMARY KEY(`id`)
);
