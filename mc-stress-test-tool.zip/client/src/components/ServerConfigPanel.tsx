import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Edit2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ServerConfigPanel() {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    serverIp: "",
    serverPort: "25565",
    minecraftVersion: "1.20.1",
    serverName: "",
  });

  const { data: configs, isLoading, refetch } = trpc.serverConfig.getConfigs.useQuery();
  const createMutation = trpc.serverConfig.createConfig.useMutation({
    onSuccess: () => {
      toast.success("Server configuration created");
      setFormData({ serverIp: "", serverPort: "25565", minecraftVersion: "1.20.1", serverName: "" });
      setIsAdding(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.serverIp) {
      toast.error("Server IP is required");
      return;
    }
    createMutation.mutate({
      serverIp: formData.serverIp,
      serverPort: parseInt(formData.serverPort),
      minecraftVersion: formData.minecraftVersion,
      serverName: formData.serverName || undefined,
    });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle>Server Configuration</CardTitle>
          <CardDescription>Manage your Minecraft server connection settings</CardDescription>
        </CardHeader>
        <CardContent>
          {!isAdding ? (
            <Button onClick={() => setIsAdding(true)} className="w-full sm:w-auto">
              <Plus className="w-4 h-4 mr-2" />
              Add Server Configuration
            </Button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="serverIp">Server IP Address</Label>
                  <Input
                    id="serverIp"
                    placeholder="e.g., 192.168.1.1"
                    value={formData.serverIp}
                    onChange={(e) => setFormData({ ...formData, serverIp: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="serverPort">Port</Label>
                  <Input
                    id="serverPort"
                    type="number"
                    placeholder="25565"
                    value={formData.serverPort}
                    onChange={(e) => setFormData({ ...formData, serverPort: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="version">Minecraft Version</Label>
                  <Select value={formData.minecraftVersion} onValueChange={(value) => setFormData({ ...formData, minecraftVersion: value })}>
                    <SelectTrigger id="version">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="1.20.1">1.20.1</SelectItem>
                      <SelectItem value="1.20">1.20</SelectItem>
                      <SelectItem value="1.19.2">1.19.2</SelectItem>
                      <SelectItem value="1.19">1.19</SelectItem>
                      <SelectItem value="1.18.2">1.18.2</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="serverName">Server Name (Optional)</Label>
                  <Input
                    id="serverName"
                    placeholder="My Test Server"
                    value={formData.serverName}
                    onChange={(e) => setFormData({ ...formData, serverName: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Creating..." : "Create Configuration"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsAdding(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>

      {configs && configs.length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-lg">Your Configurations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {configs.map((config) => (
                <div key={config.id} className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{config.serverName || config.serverIp}:{config.serverPort}</p>
                    <p className="text-sm text-muted-foreground">Version {config.minecraftVersion}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="ghost">
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive">
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
