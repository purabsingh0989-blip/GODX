import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Play, Pause, Square, Plus } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function BotControlPanel() {
  const [sessionName, setSessionName] = useState("");
  const [selectedServerConfig, setSelectedServerConfig] = useState("");
  const [selectedBotSettings, setSelectedBotSettings] = useState("");
  const [testPreset, setTestPreset] = useState("light");
  const [botCount, setBotCount] = useState("10");

  const { data: sessions, refetch: refetchSessions } = trpc.botManagement.getSessions.useQuery();
  const { data: serverConfigs } = trpc.serverConfig.getConfigs.useQuery();
  const { data: botSettings } = trpc.botSettings.getSettings.useQuery();

  const createSessionMutation = trpc.botManagement.createSession.useMutation({
    onSuccess: () => {
      toast.success("Test session created");
      setSessionName("");
      refetchSessions();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const startSessionMutation = trpc.botManagement.startSession.useMutation({
    onSuccess: () => {
      toast.success("Test session started");
      refetchSessions();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const pauseSessionMutation = trpc.botManagement.pauseSession.useMutation({
    onSuccess: () => {
      toast.success("Test session paused");
      refetchSessions();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const stopSessionMutation = trpc.botManagement.stopSession.useMutation({
    onSuccess: () => {
      toast.success("Test session stopped");
      refetchSessions();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleCreateSession = () => {
    if (!sessionName || !selectedServerConfig || !selectedBotSettings) {
      toast.error("Please fill in all required fields");
      return;
    }

    createSessionMutation.mutate({
      sessionName,
      serverConfigId: parseInt(selectedServerConfig),
      botSettingsId: parseInt(selectedBotSettings),
      testPreset: testPreset as any,
      totalBots: parseInt(botCount),
    });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle>Create New Test Session</CardTitle>
          <CardDescription>Configure and launch a new bot stress test</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="sessionName">Session Name</Label>
            <Input
              id="sessionName"
              placeholder="e.g., Peak Hour Test"
              value={sessionName}
              onChange={(e) => setSessionName(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="serverConfig">Server Configuration</Label>
              <Select value={selectedServerConfig} onValueChange={setSelectedServerConfig}>
                <SelectTrigger id="serverConfig">
                  <SelectValue placeholder="Select server" />
                </SelectTrigger>
                <SelectContent>
                  {serverConfigs?.map((config) => (
                    <SelectItem key={config.id} value={config.id.toString()}>
                      {config.serverName || config.serverIp}:{config.serverPort}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="botSettings">Bot Settings</Label>
              <Select value={selectedBotSettings} onValueChange={setSelectedBotSettings}>
                <SelectTrigger id="botSettings">
                  <SelectValue placeholder="Select settings" />
                </SelectTrigger>
                <SelectContent>
                  {botSettings?.map((setting) => (
                    <SelectItem key={setting.id} value={setting.id.toString()}>
                      {setting.settingsName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="testPreset">Test Preset</Label>
              <Select value={testPreset} onValueChange={setTestPreset}>
                <SelectTrigger id="testPreset">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="light">Light (10 bots)</SelectItem>
                  <SelectItem value="medium">Medium (50 bots)</SelectItem>
                  <SelectItem value="heavy">Heavy (100 bots)</SelectItem>
                  <SelectItem value="extreme">Extreme (250 bots)</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="botCount">Number of Bots</Label>
              <Input
                id="botCount"
                type="number"
                min="1"
                max="1000"
                value={botCount}
                onChange={(e) => setBotCount(e.target.value)}
              />
            </div>
          </div>

          <Button onClick={handleCreateSession} disabled={createSessionMutation.isPending} className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            {createSessionMutation.isPending ? "Creating..." : "Create Session"}
          </Button>
        </CardContent>
      </Card>

      {sessions && sessions.length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-lg">Active Sessions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {sessions.map((session) => (
                <div key={session.id} className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{session.sessionName}</p>
                    <p className="text-sm text-muted-foreground">
                      {session.totalBots} bots • Status: <span className="capitalize font-medium">{session.status}</span>
                    </p>
                  </div>
                  <div className="flex gap-2">
                    {session.status === "idle" && (
                      <Button
                        size="sm"
                        onClick={() => startSessionMutation.mutate({ sessionId: session.id })}
                        disabled={startSessionMutation.isPending}
                      >
                        <Play className="w-4 h-4 mr-1" />
                        Start
                      </Button>
                    )}
                    {session.status === "running" && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => pauseSessionMutation.mutate({ sessionId: session.id })}
                          disabled={pauseSessionMutation.isPending}
                        >
                          <Pause className="w-4 h-4 mr-1" />
                          Pause
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => stopSessionMutation.mutate({ sessionId: session.id })}
                          disabled={stopSessionMutation.isPending}
                        >
                          <Square className="w-4 h-4 mr-1" />
                          Stop
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
