import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Power } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function ProxyManagementPanel() {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    ipAddress: "",
    port: "",
    username: "",
    password: "",
    protocol: "http",
  });

  const { data: proxies, refetch } = trpc.proxyManagement.getProxies.useQuery();
  const createMutation = trpc.proxyManagement.addProxy.useMutation({
    onSuccess: () => {
      toast.success("Proxy added successfully");
      setFormData({ ipAddress: "", port: "", username: "", password: "", protocol: "http" });
      setIsAdding(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = trpc.proxyManagement.deleteProxy.useMutation({
    onSuccess: () => {
      toast.success("Proxy deleted");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const toggleMutation = trpc.proxyManagement.toggleProxy.useMutation({
    onSuccess: () => {
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.ipAddress) {
      toast.error("IP address is required");
      return;
    }
    createMutation.mutate({
      ipAddress: formData.ipAddress,
      port: formData.port ? parseInt(formData.port) : undefined,
      username: formData.username || undefined,
      password: formData.password || undefined,
      protocol: formData.protocol as any,
    });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle>Proxy Management</CardTitle>
          <CardDescription>Add and manage proxy IPs for bot distribution</CardDescription>
        </CardHeader>
        <CardContent>
          {!isAdding ? (
            <Button onClick={() => setIsAdding(true)} className="w-full sm:w-auto">
              <Plus className="w-4 h-4 mr-2" />
              Add Proxy IP
            </Button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="ipAddress">IP Address</Label>
                  <Input
                    id="ipAddress"
                    placeholder="e.g., 192.168.1.100"
                    value={formData.ipAddress}
                    onChange={(e) => setFormData({ ...formData, ipAddress: e.target.value })}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="port">Port</Label>
                  <Input
                    id="port"
                    type="number"
                    placeholder="8080"
                    value={formData.port}
                    onChange={(e) => setFormData({ ...formData, port: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="protocol">Protocol</Label>
                  <Select value={formData.protocol} onValueChange={(value) => setFormData({ ...formData, protocol: value })}>
                    <SelectTrigger id="protocol">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="http">HTTP</SelectItem>
                      <SelectItem value="https">HTTPS</SelectItem>
                      <SelectItem value="socks5">SOCKS5</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="username">Username (Optional)</Label>
                  <Input
                    id="username"
                    placeholder="Proxy username"
                    value={formData.username}
                    onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="password">Password (Optional)</Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Proxy password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                />
              </div>

              <div className="flex gap-2">
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Adding..." : "Add Proxy"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsAdding(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>

      {proxies && proxies.length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-lg">Your Proxies</CardTitle>
            <CardDescription>{proxies.filter((p) => p.isActive).length} active</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {proxies.map((proxy) => (
                <div key={proxy.id} className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">
                      {proxy.ipAddress}:{proxy.port || "default"}
                    </p>
                    <p className="text-sm text-muted-foreground">
                      {proxy.protocol.toUpperCase()} • {proxy.isActive ? "Active" : "Inactive"}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant={proxy.isActive ? "default" : "outline"}
                      onClick={() => toggleMutation.mutate({ proxyId: proxy.id, isActive: !proxy.isActive })}
                    >
                      <Power className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive hover:text-destructive"
                      onClick={() => deleteMutation.mutate({ proxyId: proxy.id })}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
