import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Plus, Trash2, Edit2 } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

export default function BotSettingsPanel() {
  const [isAdding, setIsAdding] = useState(false);
  const [formData, setFormData] = useState({
    settingsName: "",
    usernamePattern: "Bot_{number}",
    joinDelay: "1000",
    enableMovement: true,
    enableChat: false,
    chatInterval: "30000",
    autoRespawn: true,
  });

  const { data: settings, refetch } = trpc.botSettings.getSettings.useQuery();
  const createMutation = trpc.botSettings.createSettings.useMutation({
    onSuccess: () => {
      toast.success("Bot settings created");
      setFormData({
        settingsName: "",
        usernamePattern: "Bot_{number}",
        joinDelay: "1000",
        enableMovement: true,
        enableChat: false,
        chatInterval: "30000",
        autoRespawn: true,
      });
      setIsAdding(false);
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const deleteMutation = trpc.botSettings.deleteSettings.useMutation({
    onSuccess: () => {
      toast.success("Settings deleted");
      refetch();
    },
    onError: (error) => {
      toast.error(error.message);
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.settingsName) {
      toast.error("Settings name is required");
      return;
    }
    createMutation.mutate({
      settingsName: formData.settingsName,
      usernamePattern: formData.usernamePattern,
      joinDelay: parseInt(formData.joinDelay),
      enableMovement: formData.enableMovement,
      enableChat: formData.enableChat,
      chatInterval: parseInt(formData.chatInterval),
      autoRespawn: formData.autoRespawn,
    });
  };

  return (
    <div className="space-y-6">
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle>Bot Settings</CardTitle>
          <CardDescription>Configure bot behavior and connection parameters</CardDescription>
        </CardHeader>
        <CardContent>
          {!isAdding ? (
            <Button onClick={() => setIsAdding(true)} className="w-full sm:w-auto">
              <Plus className="w-4 h-4 mr-2" />
              Create New Settings
            </Button>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label htmlFor="settingsName">Settings Name</Label>
                <Input
                  id="settingsName"
                  placeholder="e.g., Default Behavior"
                  value={formData.settingsName}
                  onChange={(e) => setFormData({ ...formData, settingsName: e.target.value })}
                  required
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="usernamePattern">Username Pattern</Label>
                  <Input
                    id="usernamePattern"
                    placeholder="Bot_{number}"
                    value={formData.usernamePattern}
                    onChange={(e) => setFormData({ ...formData, usernamePattern: e.target.value })}
                  />
                </div>
                <div>
                  <Label htmlFor="joinDelay">Join Delay (ms)</Label>
                  <Input
                    id="joinDelay"
                    type="number"
                    value={formData.joinDelay}
                    onChange={(e) => setFormData({ ...formData, joinDelay: e.target.value })}
                  />
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="enableMovement"
                    checked={formData.enableMovement}
                    onCheckedChange={(checked) => setFormData({ ...formData, enableMovement: checked as boolean })}
                  />
                  <Label htmlFor="enableMovement" className="font-normal cursor-pointer">
                    Enable Bot Movement
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="enableChat"
                    checked={formData.enableChat}
                    onCheckedChange={(checked) => setFormData({ ...formData, enableChat: checked as boolean })}
                  />
                  <Label htmlFor="enableChat" className="font-normal cursor-pointer">
                    Enable Chat Simulation
                  </Label>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="autoRespawn"
                    checked={formData.autoRespawn}
                    onCheckedChange={(checked) => setFormData({ ...formData, autoRespawn: checked as boolean })}
                  />
                  <Label htmlFor="autoRespawn" className="font-normal cursor-pointer">
                    Auto Respawn on Death
                  </Label>
                </div>
              </div>

              {formData.enableChat && (
                <div>
                  <Label htmlFor="chatInterval">Chat Interval (ms)</Label>
                  <Input
                    id="chatInterval"
                    type="number"
                    value={formData.chatInterval}
                    onChange={(e) => setFormData({ ...formData, chatInterval: e.target.value })}
                  />
                </div>
              )}

              <div className="flex gap-2">
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending ? "Creating..." : "Create Settings"}
                </Button>
                <Button type="button" variant="outline" onClick={() => setIsAdding(false)}>
                  Cancel
                </Button>
              </div>
            </form>
          )}
        </CardContent>
      </Card>

      {settings && settings.length > 0 && (
        <Card className="border-border bg-card">
          <CardHeader>
            <CardTitle className="text-lg">Your Settings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {settings.map((setting) => (
                <div key={setting.id} className="flex items-center justify-between p-3 border border-border rounded-lg hover:bg-muted/50 transition-colors">
                  <div className="flex-1">
                    <p className="font-medium text-foreground">{setting.settingsName}</p>
                    <p className="text-sm text-muted-foreground">
                      Pattern: {setting.usernamePattern} • Delay: {setting.joinDelay}ms
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Button size="sm" variant="ghost">
                      <Edit2 className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="text-destructive hover:text-destructive"
                      onClick={() => deleteMutation.mutate({ settingId: setting.id })}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
