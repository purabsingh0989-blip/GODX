import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AlertCircle, CheckCircle, XCircle, MessageSquare, Zap } from "lucide-react";

const mockLogs = [
  {
    id: 1,
    timestamp: "14:25:32",
    botName: "Bot_001",
    eventType: "connected",
    message: "Successfully connected to server",
    details: "Latency: 2ms",
  },
  {
    id: 2,
    timestamp: "14:25:35",
    botName: "Bot_002",
    eventType: "connected",
    message: "Successfully connected to server",
    details: "Latency: 3ms",
  },
  {
    id: 3,
    timestamp: "14:25:38",
    botName: "Bot_003",
    eventType: "connected",
    message: "Successfully connected to server",
    details: "Latency: 2ms",
  },
  {
    id: 4,
    timestamp: "14:25:45",
    botName: "Bot_010",
    eventType: "kicked",
    message: "Kicked by server",
    details: "Reason: Too many connections from this IP",
  },
  {
    id: 5,
    timestamp: "14:25:50",
    botName: "Bot_015",
    eventType: "error",
    message: "Connection timeout",
    details: "No response from server after 30s",
  },
  {
    id: 6,
    timestamp: "14:25:55",
    botName: "Bot_020",
    eventType: "chat",
    message: "Chat message sent",
    details: "Message: Hello from stress test!",
  },
];

function getEventIcon(eventType: string) {
  switch (eventType) {
    case "connected":
      return <CheckCircle className="w-4 h-4 text-green-500" />;
    case "disconnected":
      return <XCircle className="w-4 h-4 text-red-500" />;
    case "kicked":
      return <AlertCircle className="w-4 h-4 text-orange-500" />;
    case "error":
      return <XCircle className="w-4 h-4 text-red-600" />;
    case "chat":
      return <MessageSquare className="w-4 h-4 text-blue-500" />;
    case "movement":
      return <Zap className="w-4 h-4 text-purple-500" />;
    default:
      return <AlertCircle className="w-4 h-4 text-gray-500" />;
  }
}

function getEventBadgeVariant(eventType: string): "default" | "secondary" | "destructive" | "outline" {
  switch (eventType) {
    case "connected":
      return "default";
    case "disconnected":
      return "destructive";
    case "kicked":
      return "destructive";
    case "error":
      return "destructive";
    case "chat":
      return "secondary";
    default:
      return "outline";
  }
}

export default function ActivityLogs() {
  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle>Activity Logs</CardTitle>
        <CardDescription>Real-time bot connection events and server responses</CardDescription>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96 pr-4">
          <div className="space-y-2">
            {mockLogs.map((log) => (
              <div
                key={log.id}
                className="flex items-start gap-3 p-3 rounded-lg border border-border hover:bg-muted/50 transition-colors"
              >
                <div className="mt-1">{getEventIcon(log.eventType)}</div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-sm font-mono text-muted-foreground">{log.timestamp}</span>
                    <span className="font-medium text-foreground text-sm">{log.botName}</span>
                    <Badge variant={getEventBadgeVariant(log.eventType)} className="text-xs">
                      {log.eventType}
                    </Badge>
                  </div>
                  <p className="text-sm text-foreground">{log.message}</p>
                  <p className="text-xs text-muted-foreground mt-1">{log.details}</p>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
