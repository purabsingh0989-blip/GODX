import { useState } from "react";
import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { AlertCircle, Activity, Zap, Users, Network, Settings, Plus } from "lucide-react";
import ServerConfigPanel from "@/components/ServerConfigPanel";
import BotControlPanel from "@/components/BotControlPanel";
import ProxyManagementPanel from "@/components/ProxyManagementPanel";
import BotSettingsPanel from "@/components/BotSettingsPanel";
import PerformanceMonitor from "@/components/PerformanceMonitor";
import ActivityLogs from "@/components/ActivityLogs";

export default function Dashboard() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState("overview");

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-background">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-accent mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="border-b border-border bg-card sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
                <Zap className="w-8 h-8 text-accent" />
                Minecraft Stress Test Tool
              </h1>
              <p className="text-sm text-muted-foreground mt-1">
                Test your server capacity with precision and elegance
              </p>
            </div>
            <div className="text-right">
              <p className="text-sm text-muted-foreground">Welcome, {user?.name || "User"}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 mb-8">
            <TabsTrigger value="overview" className="flex items-center gap-2">
              <Activity className="w-4 h-4" />
              <span className="hidden sm:inline">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="server" className="flex items-center gap-2">
              <Network className="w-4 h-4" />
              <span className="hidden sm:inline">Server</span>
            </TabsTrigger>
            <TabsTrigger value="bots" className="flex items-center gap-2">
              <Users className="w-4 h-4" />
              <span className="hidden sm:inline">Bots</span>
            </TabsTrigger>
            <TabsTrigger value="proxies" className="flex items-center gap-2">
              <Network className="w-4 h-4" />
              <span className="hidden sm:inline">Proxies</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="w-4 h-4" />
              <span className="hidden sm:inline">Settings</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
              <Card className="border-border bg-card hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Active Sessions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">0</div>
                  <p className="text-xs text-muted-foreground mt-1">Running tests</p>
                </CardContent>
              </Card>

              <Card className="border-border bg-card hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Total Bots</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">0</div>
                  <p className="text-xs text-muted-foreground mt-1">Connected</p>
                </CardContent>
              </Card>

              <Card className="border-border bg-card hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Server TPS</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-accent">20.0</div>
                  <p className="text-xs text-muted-foreground mt-1">Ticks per second</p>
                </CardContent>
              </Card>

              <Card className="border-border bg-card hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="text-sm font-medium text-muted-foreground">Avg Latency</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">-- ms</div>
                  <p className="text-xs text-muted-foreground mt-1">Network delay</p>
                </CardContent>
              </Card>
            </div>

            <PerformanceMonitor />
            <ActivityLogs />
          </TabsContent>

          {/* Server Configuration Tab */}
          <TabsContent value="server" className="space-y-6">
            <ServerConfigPanel />
          </TabsContent>

          {/* Bot Control Tab */}
          <TabsContent value="bots" className="space-y-6">
            <BotControlPanel />
          </TabsContent>

          {/* Proxy Management Tab */}
          <TabsContent value="proxies" className="space-y-6">
            <ProxyManagementPanel />
          </TabsContent>

          {/* Bot Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <BotSettingsPanel />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
